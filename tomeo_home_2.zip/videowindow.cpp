#include "videowindow.h"

videoWindow::videoWindow(QWidget *parent)
    : QVideoWidget{parent}
{

}
