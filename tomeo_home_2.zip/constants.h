#ifndef CONSTANTS_H
#define CONSTANTS_H

#define APP_WIDTH 878/2
#define APP_HEIGHT 1792/2

// Debug Macro
// Change DEBUG_ENABLE to true to enable debug messages
#define DEBUG_ENABLE true

#ifdef DEBUG_ENABLE
#define DEBUG_MSG(str) do { qDebug() << str; } while(0);
#else
#define DEBUG_MSG(str) do {} while (0);
#endif

#endif // CONSTANTS_H
