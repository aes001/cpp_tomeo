#include <QApplication>
#include <QLabel>
#include <QtWidgets/QWidget>
#include <QVBoxLayout>
#include <vector>
#include <QMediaPlayer>
#include <QtMultimediaWidgets/QVideoWidget>
#include "constants.h"
#include "videoplayer.h"
#include <iostream>
#include "readvideos.h"
#include <QMessageBox>
#include <QScrollArea>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    std::vector<videoPlayer*> videos;

    if (argc == 2)
        videos = readVideos(std::string(argv[1]));

    if (videos.size() == 0) {
        QMessageBox::information(
            NULL,
            QString("Tomeo"),
            QString("No videos found! Add command line argument to \"quoted\" file location."));
        exit(-1);
    }

    // Once we have verified that we have videos, we can create the window and layout

    QWidget *window = new QWidget();
    window->setMaximumSize(APP_WIDTH, APP_HEIGHT);
    window->setMinimumSize(APP_WIDTH, APP_HEIGHT);
    window->setWindowTitle("Tomeo");

    QVBoxLayout *layout = new QVBoxLayout();

    QScrollArea *scrollArea = new QScrollArea(window);
    QWidget *scrollAreaWidgetContents = new QWidget(scrollArea);
    scrollArea->setWidgetResizable(true);
    scrollArea->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    scrollArea->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    scrollAreaWidgetContents->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Fixed);
    scrollArea->setWidget(scrollAreaWidgetContents);
    scrollAreaWidgetContents->setLayout(layout);
    layout->setContentsMargins(0, 0, 0, 0);

    QLabel *header = new QLabel("My Videos", window);
    QFont font = header->font();
    font.setPointSize(24);
    font.setBold(true);
    header->setFont(font);
    header->setAlignment(Qt::AlignHCenter);
    layout->addWidget(header);

    // Add the videos to the layout
    for (int i = 0; i < (int) videos.size(); i++) {
        videos.at(i)->setParent(window);
        layout->addWidget(videos.at(i));

////        QWidget *playButtonTest = new QWidget(window);
//        QVBoxLayout *videoControlsLayout = new QVBoxLayout();

//        QWidget *playButtonContainer = new QWidget(videos.at(i));
//        QHBoxLayout *playButtonLayout = new QHBoxLayout();
//        playButtonLayout->setContentsMargins(0, 0, 0, 0);
//        playButtonLayout->setAlignment(Qt::AlignCenter);
//        playButtonContainer->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
//        videoControlsLayout->addWidget(playButtonContainer);
//        playButtonContainer->setLayout(playButtonLayout);
//        QLabel *playButton = new QLabel(playButtonContainer);
//        QPixmap pic = QPixmap("C:\\Users\\aesun\\Documents\\Tasks and Homeworks\\Uni 21\\User Interfaces\\Tomeo 4\\Tomeo4\\Assets\\play.png");
//        pic = pic.scaled(APP_WIDTH/5, APP_WIDTH/5, Qt::KeepAspectRatio);
//        playButton->setPixmap(pic);
//        playButton->setAlignment(Qt::AlignCenter);
//        videoControlsLayout->addWidget(playButton);

//        videoControlsLayout->setContentsMargins(0, 0, 0, 0);

//        videos.at(i)->setLayout(videoControlsLayout);


        QSpacerItem *spacer = new QSpacerItem(0, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);
        layout->addItem(spacer);
    }

    QVBoxLayout *mainLayout = new QVBoxLayout(window);
    mainLayout->setContentsMargins(0, 0, 0, 0);
    mainLayout->addWidget(scrollArea);

    window->setLayout(mainLayout);

    window->show();
    return a.exec();
}
