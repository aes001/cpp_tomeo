#ifndef VIDEOPLAYER_H
#define VIDEOPLAYER_H

#include <QObject>
#include <QWidget>
#include <QUrl>
#include <QVideoWidget>
#include <QMediaPlayer>
#include <iostream>
#include <cmath>
#include "constants.h"


class videoPlayer: public QVideoWidget
{
    Q_OBJECT
public:
    videoPlayer(QUrl videoUrl, QWidget *parent = nullptr);

protected:
    void mousePressEvent(QMouseEvent *event) override;

private:
    QMediaPlayer *player;
    QUrl videoUrl;
    bool resized = false;

public slots:
    void resizePlayer();
    void playStateChanged(QMediaPlayer::State state);
    void togglePlay();

signals:
    void windowResized();
    void clicked();
};

#endif // VIDEOPLAYER_H
